# Discord-Fake-Mute (Discord Web)

Help - discord.gg/security

# | How to use

**1** - **Join voice channel**

**2** - **Mute and deafen yourself**

**3** -  **Cntrl + Shift + I**

**4** -  **Put the code on the console**

**5** - **Now you faked your mic!**


``After you turned ON the plugin , you cant join any other voice channels , for this you have to Reload discord!`
